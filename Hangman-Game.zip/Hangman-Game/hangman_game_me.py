from Class import hangman
import random

def man(wrong_guesses):         #Takes number of incorrect guesses to generate the hangman
  if wrong_guesses == 0:
    hang = "_______\n |    |     \n |\n |\n |\n |\n |\n_|_____"
  elif wrong_guesses == 1:
    hang = "_______\n |    |     \n |   (_)\n |\n |\n |\n |\n_|_____"
  elif wrong_guesses == 2:
    hang = "_______\n |    |     \n |   (_)\n |    |\n |    |\n |\n |\n_|_____"
  elif wrong_guesses == 3:
    hang = "_______\n |    |     \n |   (_)\n |   \|\n |    |\n |\n |\n_|_____"
  elif wrong_guesses == 4:
    hang = "_______\n |    |     \n |   (_)\n |   \|/\n |    |\n |\n |\n_|_____"
  elif wrong_guesses == 5:
    hang = "_______\n |    |     \n |   (_)\n |   \|/\n |    |\n |   /\n |\n_|_____"
  elif wrong_guesses == 6:
    hang = "_______\n |    |     \n |   (_)\n |   \|/\n |    |\n |   / \ \n |\n_|_____"

  return (hang)


def choose_topic():
    topic = input("Please enter the topic that you would like. The available topics are: 'Capital Cities', 'Major Tech Companies', 'Deserts', 'Colours'")
    while True:
        try:
            if topic == "Capital Cities":
                player.word = random.choice(open('capital_cities.txt').read().split()).strip()
            elif topic == "Major Tech Companies":
                player.word = random.choice(open('major_tech_companies.txt').read().split()).strip()
            elif topic == "Deserts":
                player.word = random.choice(open('deserts.txt').read().split()).strip()
            elif topic == "Colours":
                player.word = random.choice(open('colours.txt').read().split()).strip()
            break
        except ValueError:
            print("That's not a valid topic")
    return player.word 
    


  def main:
      choose_topic()
      wrong_guesses = 0
      while True:
          print(player.word_to_blanks)
          guess = input(str("Enter a letter to guess"))
          if player.location_list == []:
              wrong_guesses += 1
              print(man(wrong_guesses))
          print(player.fill_in_blanks)
          